﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpApplication
{
    class Class2
    {
        static void Main()
        {
            DataSet ds = new DataSet("Employeee information");
            DataTable dt = new DataTable("Emp");
            DataTable dt2 = new DataTable("Salary");

            #region datatable
            DataColumn dc1 = new DataColumn("Empcode",typeof(Int32));
            DataColumn dc2 = new DataColumn("EmpName",typeof(string));
            DataColumn dc3 = new DataColumn("Email",typeof(string));

            //adding columns to datatable
            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);
            dt.Columns.Add(dc3);

            //setting primary key
            dt.PrimaryKey = new DataColumn[] { dc1 };

            //setting unique constarint
            Constraint unique = new UniqueConstraint(dc3);
            dt.Constraints.Add(unique);
            #endregion

            //adding datatable to dataset
            ds.Tables.Add(dt);

            #region datarows
            DataRow dtr1 = dt.NewRow();
            dtr1[0] = 1;
            dtr1["EmpName"] = "Scott";
            dtr1[2] = "scott@gmail.com";

            dt.Rows.Add(dtr1);

            #endregion

            foreach (DataRow row in dt.Rows)
            {
                Console.WriteLine($"{row[0]} \t{row[1]}\t {row[2]}");
            }



            //second table salary 
            DataColumn dc21 = new DataColumn("EmpCode",typeof(int));
            DataColumn dc22 = new DataColumn("Basic",typeof(double));

            dt2.Columns.Add(dc21);
            dt2.Columns.Add(dc22);

            ds.Tables.Add(dt2);
            
            saveAsXml(ds);

            getXml(ds);

            getXmlSchema(ds); 
            Console.WriteLine("data set has been created");
            Console.ReadLine();
        }


        public void createContraint(DataTable parentTable,DataTable childTable,DataColumn parentcol,DataColumn childcol,DataSet ds)
        {
            ForeignKeyConstraint fk = new ForeignKeyConstraint("fk_sal_column",parentcol,childcol);
            fk.DeleteRule = Rule.Cascade;

            fk.AcceptRejectRule = AcceptRejectRule.Cascade;
            ds.Tables["Salary"].Constraints.Add(fk);
            ds.EnforceConstraints = true;
        }


        static void saveAsXml(DataSet ds)
        {
            ds.WriteXml("student.xml");
            Console.WriteLine("data Exported into xml file");
        }
        static void getXml(DataSet ds)
        {
            Console.WriteLine($"{ds.GetXml()}");
        }
        static void getXmlSchema(DataSet ds)
        {
            Console.WriteLine($"{ds.GetXmlSchema()}");
        }
    }
}
