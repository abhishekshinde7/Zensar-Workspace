﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EmpApplication.EntityModel;

namespace EmpApplication.DataAccessLayer
{
    class SalaryInfoDal1
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        public List<SalaryInfo> EmployeeSalaries(int empcode)
        {
            List<SalaryInfo> listSal = new List<SalaryInfo>();
            try
            {
                ds.Reset();
                da = new SqlDataAdapter("EmployeeSalarys", sqlcon);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@Empcode", SqlDbType.Int).Value = empcode;
                da.Fill(ds, "EmpSal");
                if (ds.Tables["EmpSal"].Rows.Count > 0)
                {
                    foreach (DataRow dtr in ds.Tables["EmpSal"].Rows)
                    {
                        SalaryInfo sal = new SalaryInfo();
                        sal.SalarySheetNo = Convert.ToInt32(dtr["SalarySheetNo"]);
                        sal.EmpCode = Convert.ToInt32(dtr["EmpCode"]);
                        sal.DateOfSalary = Convert.ToDateTime(dtr["DateOfSalary"]);
                        sal.Basic = Convert.ToDouble(dtr["Basic"]);
                        sal.Hra= Convert.ToDouble(dtr["Hra"]);
                        sal.Da = Convert.ToDouble(dtr["Da"]);
                        sal.NetSalary = Convert.ToDouble(dtr["NetSalary"]);
                        listSal.Add(sal);
                    }
                    
                }
                return listSal;
            }
            catch(Exception ex)
            {
                return listSal;
            }
            
        }
    }
}
