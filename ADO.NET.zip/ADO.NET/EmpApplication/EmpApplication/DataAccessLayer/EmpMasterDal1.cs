﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.EntityModel;
using System.Data;
using System.Data.SqlClient;

namespace EmpApplication.DataAccessLayer
{
    class EmpMasterDal1
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlDataAdapter da;
        DataSet ds = new DataSet();

        public bool SaveEmployee(EmpMaster emp)
        {
            try
            {
                //da = new SqlDataAdapter("insert into empMaster values(" + emp.EmpCode + ",'" + emp.EmpName + "','"
                // + emp.EmpDate + "','" + emp.EmpGender + "','" + emp.EmpDepartmnet + "','" + emp.EmpDesignation + "')",sqlcon);

                da = new SqlDataAdapter("SaveEmployee", sqlcon);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@empcode", SqlDbType.Int).Value = emp.EmpCode;
                da.SelectCommand.Parameters.Add("@empname", SqlDbType.NVarChar).Value = emp.EmpCode;
                da.SelectCommand.Parameters.Add("@EmpDob", SqlDbType.DateTime).Value = emp.EmpDate;
                da.SelectCommand.Parameters.Add("@EmpGender	", SqlDbType.NVarChar).Value = emp.EmpGender;
                da.SelectCommand.Parameters.Add("@EmpDepartment", SqlDbType.NVarChar).Value = emp.EmpDepartmnet;
                da.SelectCommand.Parameters.Add("@EmpDesignation", SqlDbType.NVarChar).Value = emp.EmpDesignation;

                da.Fill(ds);
                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
            
           
        }

        public bool DeleteEmployee(int empcode)
        {
            try
            {
                da = new SqlDataAdapter("delete from empmaster where empcode="+empcode, sqlcon);
                da.Fill(ds);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }


        }

        public bool UpdateEmployee(EmpMaster emp)
        {
            try
            {
                da = new SqlDataAdapter("update Empmaster set EmpName='" + emp.EmpName + "',EmpDob='"
                    + emp.EmpDate + "',EmpGender='" + emp.EmpGender + "',EmpDepartment='" + emp.EmpDepartmnet + "',EmpDesignation='" + emp.EmpDesignation + "' where EmpCode=" + emp.EmpCode,sqlcon);
                da.Fill(ds);
                return true;
            }
            catch(SqlException ex)
            {
                return false;
            }
        }

        public List<EmpMaster> viewAllEmployees()
        {
            List<EmpMaster> emplist = new List<EmpMaster>();
            try
            {
                ds.Reset();
                da = new SqlDataAdapter("Select * from empMaster",sqlcon);
                da.Fill(ds, "Emp");
             if(ds.Tables["Emp"].Rows.Count > 0)
                {
                  
                    foreach (DataRow dtr in ds.Tables["Emp"].Rows)
                    {
                        EmpMaster emp = new EmpMaster();
                        emp.EmpCode = Convert.ToInt32(dtr["EmpCode"]);
                        emp.EmpName = dtr["EmpName"].ToString();
                        emp.EmpDate = Convert.ToDateTime(dtr["EmpDob"]);
                        emp.EmpGender = dtr["EmpGender"].ToString();
                        emp.EmpDepartmnet = dtr["EmpDepartMent"].ToString();
                        emp.EmpDesignation = dtr["EmpDesignation"].ToString();
                        emplist.Add(emp);
                    }
                }
                return emplist;
            }
            catch (Exception ex)
            {
                return emplist;
            }
        }
    }
}
