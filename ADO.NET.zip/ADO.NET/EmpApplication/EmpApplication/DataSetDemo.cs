﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DataAccessLayer;
using EmpApplication.EntityModel;


namespace EmpApplication
{
    class DataSetDemo
    {
        static void Main()
        {
            EmpMasterDal1 empdal = new EmpMasterDal1();
            Console.WriteLine("enter 1.save 2.delete 3.update 4.view 5.employee SAlaries 6.show form");
            int response = Convert.ToInt32(Console.ReadLine());
            switch (response)
            {
                case 1:
                    EmpMaster emp = new EmpMaster()
                    {
                        EmpCode = 101,
                        EmpName = "Anjali",
                        EmpDate = Convert.ToDateTime("1980-02-01"),
                        EmpGender = "male",
                        EmpDepartmnet = "sales",
                        EmpDesignation = "manager"
                    };
                    if (empdal.SaveEmployee(emp))
                    {
                        Console.WriteLine("Employee Info Saved");
                    }
                    else
                    {
                        Console.WriteLine("Employee info saved");
                    }
                    break;

                case 3:
                    EmpMasterDal1 empdal1 = new EmpMasterDal1();
                    EmpMaster emp1 = new EmpMaster() { EmpCode = 100, EmpName = "randam", EmpDate = Convert.ToDateTime("1980-02-01"), EmpGender = "female", EmpDepartmnet = "sales", EmpDesignation = "manager" };
                    if (empdal1.UpdateEmployee(emp1))
                    {
                        Console.WriteLine("Employee Information Updated");
                    }
                    else
                    {
                        Console.WriteLine("Error Occured");
                    }
                    break;
                case 4:
                    EmpMasterDal1 empdal2 = new EmpMasterDal1();
                    List<EmpMaster> emplist = empdal2.viewAllEmployees();
                    if (emplist.Count > 0)
                    {
                        foreach (EmpMaster empO in emplist)
                        {
                            Console.WriteLine($"{empO.EmpName}\t {empO.EmpDate}\t {empO.EmpGender}\t {empO.EmpDepartmnet}\t {empO.EmpDesignation}");
                        }
                    }
                    else
                    {

                    }
                    break;

                case 5:
                    SalaryInfoDal1 saldal = new SalaryInfoDal1();
                    List<SalaryInfo> listsal = saldal.EmployeeSalaries(1);
                    if (listsal.Count > 0)
                    {
                        foreach(SalaryInfo sal in listsal)
                        {
                            Console.WriteLine($"{sal.EmpCode}\t {sal.DateOfSalary}\t {sal.Basic}\t {sal.Hra}\t {sal.NetSalary} \t {sal.SalarySheetNo} ");
                        }
                    }
                    else
                    {
                        Console.WriteLine("no salaries found");
                    }
                    break;
                case 6:
                    frmDataBinding frm = new frmDataBinding();
                    frm.Show();
                    break;
                default:
                    break;
                    
            }
            Console.ReadLine();
        }
       
    }
}
