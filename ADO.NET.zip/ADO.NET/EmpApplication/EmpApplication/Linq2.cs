﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DataAccessLayer;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    class Linq2
    {
        static void Main()
        {
            List<Student> studentList = new List<Student>()
            {
                new Student() {StudentID=1,StudentName="john",Age=13 },
                new Student() {StudentID=2,StudentName="moin",Age=21 },
                new Student() {StudentID=3,StudentName="bill",Age=18 },
                new Student() {StudentID=4,StudentName="Ram",Age=20},
                new Student() {StudentID=5,StudentName="Ron",Age=15 }
            };

            var result = from s in studentList where s.Age > 20 select s;
            foreach (Student i in result)
            {
                Console.WriteLine($"{i.StudentID}\t {i.StudentName}\t{i.Age}");
            }

            Console.WriteLine("___________________________________________________________");
            Console.WriteLine($"display info of student whose name is jhon");
            var result2 = from s in studentList where s.StudentName == "john" select s;
            foreach (var i in result2)
            {
                Console.WriteLine($"{i.StudentID}\t {i.StudentName}\t{i.Age}");
            }

            Console.WriteLine("___________________________________________________________");
            Console.WriteLine($"display by using database");
            //using data base
            EmpMasterDAL empdal = new EmpMasterDAL();
            EmpMaster emp = new EmpMaster();
            List<EmpMaster> emplist = empdal.ViewAllEmployee();
            var result3 = from s in emplist where s.EmpDepartmnet == "sales" select new {s.EmpCode,s.EmpName };

            foreach (var i in result3)
            {
                Console.WriteLine($"{i.EmpName}\t {i.EmpCode}");
            }

            Console.WriteLine("___________________________________________________________");
            //sorting order
            var resultbyorder = from s in emplist orderby s.EmpGender select s;
            foreach (var i in resultbyorder)
            {
                Console.WriteLine($"{i.EmpName}\t {i.EmpCode}\t {i.EmpGender}");
            }
            Console.WriteLine("___________________________________________________________");
            //decending
            var resultbyorderDesc = from s in emplist orderby s.EmpGender descending select s;
            foreach (var i in resultbyorderDesc)
            {
                Console.WriteLine($"{i.EmpName}\t {i.EmpCode}\t {i.EmpGender}");
            }
            Console.ReadLine();
        }
    }
}
