﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpApplication
{
    class Linq
    {
        static void Main()
        {
            List<string> strlist = new List<string>()
           {
               "sdsad","zzzz","aaaaal","ooooolo","llllll"
           };

            var result = from s in strlist where s.Contains("a") select s;
            var result1 = strlist.Where(s=>s.Contains("l"));

            foreach (var v in result)
            {
                Console.WriteLine(v);
            }

            Console.ReadLine();
        }
    }

    public class Student
    {
        public int Age { get; set; }
        public int StudentID { get; set; }
        public string StudentName { get; set; }
    }
}
