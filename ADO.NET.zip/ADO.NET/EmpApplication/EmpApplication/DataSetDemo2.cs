﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpApplication
{
    class DataSetDemo2
    {
        static void Main()
        {
            DataSetUse dobj = new DataSetUse();
            DataSet ds = new DataSet("Employee table");
            DataTable dt = dobj.CreateTableStruc();
        
            ds.Tables.Add(dobj.AddData(dt));    //   dt=dobj.AddData(dt);
            dobj.display(ds);
            Console.ReadLine();

        }
    }

  public   class DataSetUse
    {
     public   DataTable CreateTableStruc()
        {
            DataTable dt = new DataTable("Emp");

            DataColumn dc1 = new DataColumn("Empcode", typeof(Int32));
            DataColumn dc2 = new DataColumn("EmpName", typeof(string));
            DataColumn dc3 = new DataColumn("Email", typeof(string));

            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);
            dt.Columns.Add(dc3);

            return dt;
        }

        public  DataTable AddData(DataTable dt)
        {
            DataRow dtr1 = dt.NewRow();
            dtr1[0] = 1;
            dtr1["EmpName"] = "Scott";
            dtr1[2] = "scott@gmail.com";

            dt.Rows.Add(dtr1);
            return dt;
        }

        public void display(DataSet ds)
        {
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                Console.WriteLine($"{row[0]} \t{row[1]}\t {row[2]}");
            }
        }
        
    }
}
