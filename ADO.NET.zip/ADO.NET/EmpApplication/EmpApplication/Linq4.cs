﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DataAccessLayer;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    class Linq4
    {
        static void Main()
        {
            Console.WriteLine("------------------------All----------------------------------------------");
            List<SalaryInfo> salarylist = new List<SalaryInfo>();
            SalaryInfoDal1 saldal = new SalaryInfoDal1();
            EmpMasterDAL empdal = new EmpMasterDAL();

            List<EmpMaster> emplist = new List<EmpMaster>();

            emplist = empdal.ViewAllEmployee();
            salarylist = saldal.EmployeeSalaries(1);
           bool Isallbybasic = salarylist.All(s=>s.Basic>=80000);
            Console.WriteLine($"is All Employees has Basic >=80000  {Isallbybasic}");

            bool IsAnyByBasic = salarylist.Any((s => s.Basic >= 80000));
            Console.WriteLine($"do Any Employees has Basic >=80000  {Isallbybasic}");

            double avgbyBasic = salarylist.Average(s=>s.Basic);
            int[] nums = {10,20,30,40,50};
            double intavg = nums.Average();
            Console.WriteLine($"average by basic :{avgbyBasic}");

            double salcount = salarylist.Count(s => s.Basic>=80000);
            Console.WriteLine($"count of salaries :{avgbyBasic}");

            double disticntcount = salarylist.Distinct().Count(s => s.Basic >= 80000);
            Console.WriteLine($"distinct count :{disticntcount}");

            double maxbasic = salarylist.Max(s=>s.Basic);
            Console.WriteLine($"distinct count :{maxbasic}");

            var first = salarylist.FirstOrDefault(s=>s.Basic>=80000);
     //       Console.WriteLine($"first :{first.EmpCode}\t {first.Basic} \t{first.Hra}\t{first.Da}");

            var last = salarylist.Last(s=>s.EmpCode==1);
    //        Console.WriteLine($"first :{first.EmpCode}\t {first.SalarySheetNo} \t{first.Hra}\t{first.Da}");

            var elementat = salarylist.ElementAt(2);
    //        Console.WriteLine($"first :{first.EmpCode}\t {first.Basic} \t{first.Hra}\t{first.Da}");

            var range = Enumerable.Range(0, 2);
            Console.WriteLine($"total count:{range.Count()}");
            foreach (var item in range)
            {
                Console.WriteLine($" Value at Index {item}");
            }

            string[] str1 = {"one","two","three","four" };
            string[] str2 = { "one", "two" };
            var execptresult = str1.Except(str2);

            foreach (var v in execptresult)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine("_______________________");

            var intersectresult = str1.Intersect(str2);
            foreach (var v in intersectresult)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine("_______________________");
            var unionresult = str1.Union(str2);
            foreach (var v in unionresult)
            {
                Console.WriteLine(v);
            }

            Console.ReadLine();




        }
    }
}
