﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DataAccessLayer;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    class Linq3
    {
        static void Main()
        {
            List<EmpMaster> emplist = new List<EmpMaster>();
            List<SalaryInfo> salarylist = new List<SalaryInfo>();
            EmpMasterDAL empdal = new EmpMasterDAL();
            SalaryInfoDal1 saldal = new SalaryInfoDal1();

            emplist = empdal.ViewAllEmployee();
            salarylist = saldal.EmployeeSalaries(1);

            var result = from emp in emplist
                         join salary in salarylist on emp.EmpCode equals salary.EmpCode
                         select new { emp.EmpCode, emp.EmpName, salary.Basic, salary.NetSalary };

            foreach (var v in result)
            {
                Console.WriteLine($"{v.EmpCode} \t{v.EmpName} \t{v.Basic} \t {v.NetSalary}");
            }

            Console.WriteLine("------------------------group by----------------------------");

            var groupbyresult = from e in salarylist group e by e.EmpCode;
            foreach (var v in groupbyresult)
            {
                Console.WriteLine($"employee code group:{v.Key} ");
                foreach (var k in v)
                {
                    Console.WriteLine($"{k.Basic}\t{k.DateOfSalary} \t{k.NetSalary}");
                }
            }


            Console.WriteLine("------------------------group by with join----------------------------");
            //var result2 = from emp in emplist
            //              group emp by emp.EmpCode into pg
            //              join salary in salarylist on pg.FirstOrDefault().EmpCode equals salary.EmpCode


            //             select new { EmpCode=pg.FirstOrDefault().EmpCode,EmpName=pg.FirstOrDefault().EmpName, salary.Basic, salary.NetSalary } ;

            //foreach (var v in groupbyresult)
            //{
            //    Console.WriteLine($"employee code group:{v.Key} ");
            //    foreach (var k in v)
            //    {
            //        Console.WriteLine($"{v.FirstOrDefault().}\t{k.Basic}\t{k.DateOfSalary} \t{k.NetSalary}");
            //    }
            //}
            var groupbywithjoins = emplist.GroupJoin(salarylist, e => e.EmpCode, s => s.EmpCode, (employees, salaries) => new { employees, salaries });
            foreach (var emp in groupbywithjoins)
            {
                Console.WriteLine($"{emp.employees.EmpCode} \t {emp.employees.EmpName}");
                foreach (var sal in emp.salaries)
                {

                    Console.WriteLine($"{sal.Basic}\t{sal.DateOfSalary} \t{sal.NetSalary}");
                }
            }

            Console.ReadLine();
            
            
        }
    }
}
