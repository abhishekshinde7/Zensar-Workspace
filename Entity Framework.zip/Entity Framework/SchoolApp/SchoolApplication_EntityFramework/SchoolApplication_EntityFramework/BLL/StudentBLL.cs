﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolApplication_EntityFramework.BLL
{
    public class StudentBLL
    {
        public GetStudentById_Result getStudentById(int i)
        {
            
            try
            {
                GetStudentById_Result so = new GetStudentById_Result();
                using (DBschoolEntities dbcontext = new DBschoolEntities())
                {
                 var  s=dbcontext.GetStudentById(102).First();
                    //  Console.WriteLine($"{s.StandardId}\t{s.StudentName}\t{s.StandardId}");
                    so = s;

                }
                return so;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

      
    }
}
