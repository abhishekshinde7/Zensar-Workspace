﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolApplication_EntityFramework.BLL
{
    class StandardBLL
    {
        public bool saveStandard(Standard std)
        {
            try
            {
                using (DBschoolEntities dbcontext = new DBschoolEntities())
                {
                 //   dbcontext.Database.ExecuteSqlCommand(""); //use of nativequery but performance will be low
                    dbcontext.Standards.Add(std);
                    dbcontext.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
          
        }

        public bool deleteStandard()
        {
            try
            {
                using (DBschoolEntities dbcontext = new DBschoolEntities())
                {
                    //  var s = dbcontext.Standards.First<Standard>();
                    // var s = dbcontext.Standards.Find(2);                      //by using extention method

                    var s = dbcontext.Standards.First<Standard>(x=>x.StandardId==3);     //by using lambda expression
                    dbcontext.Standards.Remove(s);
                    dbcontext.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
          
        }


        public bool updateStandard(Standard std)
        {
            try
            {
                using (DBschoolEntities dbcontext=new DBschoolEntities())
                {
                    var s = dbcontext.Standards.Find(std.StandardId);
                    s.StandardName = std.StandardName;
                    s.Description = std.Description;
                    
                    dbcontext.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public Standard viewStandard(int id)
        {
            try
            {
                Standard std;
                using (DBschoolEntities dbcontext=new DBschoolEntities())
                {
                    //var s = dbcontext.Standards.Where(x=>x.StandardId==id).First();
                    // var  s = from st in dbcontext.Standards where st.StandardId == id select st;
                    var s = dbcontext.Standards.Where(x => x.StandardId == id);
                    std = s.First();
                }
                return std ;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public List<Standard> viewAllStandards()
        {
            List<Standard> stdlist = new List<Standard>();

            using(DBschoolEntities dbcontext=new DBschoolEntities())
            {
                var s = dbcontext.Standards.ToList();
                stdlist = s;
            }
            return stdlist;
        }

        /// <summary>
        /// Use of native Query
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Standard ViewStandardUsingNativeQuery(int id)
        {
            try
            {
                using (DBschoolEntities dbcontext = new DBschoolEntities())
                {

                    Standard s = dbcontext.Standards.SqlQuery("Select * from Standard where standardid=" + id + "").First();
                    return s;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        
        /// <summary>
        /// using stored procedure insert values in db tables
        /// </summary>
        /// <param name="std"></param>
        /// <returns></returns>
        public int SaveStandard(Standard std)
        {
            try
            {
                using (DBschoolEntities dbcontext=new DBschoolEntities())
                {
                   int no = dbcontext.SaveStandard(std.StandardId,std.StandardName,std.Description);
                    dbcontext.SaveChanges();
                }
                return 1;
            }
            catch(Exception ex)
            {
                return 0;
            }
        }


    }
}
