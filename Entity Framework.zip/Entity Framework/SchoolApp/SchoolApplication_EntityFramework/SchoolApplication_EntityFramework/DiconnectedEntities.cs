﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace SchoolApplication_EntityFramework
{
    class DiconnectedEntities
    {
        static void Main()
        {
            //Student std = new Student()
            //{
            //    StudentId = 106,
            //    StudentName = "Sam",
            //    StandardId = 12,
            //    Standard=new Standard()                //calling constructure of standard table
            //    {
            //        StandardId=12,StandardName="12th",Description="college"
            //    }
            //};

            //using(DBschoolEntities dbcontext=new DBschoolEntities())
            //{
            //    dbcontext.Entry(std).State = EntityState.Added;
            //    foreach (var entity in dbcontext.ChangeTracker.Entries())
            //    {
            //        Console.WriteLine($" Entity Name:{entity.Entity.GetType()}\t State:{entity.State}");
            //    }
            //    dbcontext.SaveChanges();
            //}


            StudentAddress stdA = new StudentAddress()
            {
                StudentId=112,Address1="abc",Address2="xyz",City="pune",State="MH",
                Student=new Student()
                {
                    StudentId=112,StudentName="Abhishek",StandardId=12
                }
            };
            using (DBschoolEntities dbcontext = new DBschoolEntities())
            {
                dbcontext.Entry(stdA).State = EntityState.Added;
                foreach (var entity in dbcontext.ChangeTracker.Entries())
                {
                    Console.WriteLine($" Entity Name:{entity.Entity.GetType()}\t State:{entity.State}");
                }
                dbcontext.SaveChanges();
            }


            Console.ReadLine();


        }
    }
}
