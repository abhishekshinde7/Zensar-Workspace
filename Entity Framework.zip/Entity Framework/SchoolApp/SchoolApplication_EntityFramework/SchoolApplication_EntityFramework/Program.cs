﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SchoolApplication_EntityFramework.BLL;

namespace SchoolApplication_EntityFramework
{
    class Program
    {
        static void Main(string[] args)
        {
            StandardBLL stdbll = new StandardBLL();
            Console.WriteLine("1.Enter 2.Delete 3.Update 4.View");
            int response = Convert.ToInt32(Console.ReadLine());

            switch (response)
            {
                case 1:
                    Standard std = new Standard()
                    {
                        StandardId = 1,
                        StandardName = "I",
                        Description = "juniour"
                    };
                    if (stdbll.saveStandard(std))
                    {
                        Console.WriteLine("Standard Added Successfully");
                    }
                    else
                    {
                        Console.WriteLine("Error...");
                    }
                    break;
                case 2:
                    if (stdbll.deleteStandard())
                    {
                        Console.WriteLine("Standard deleted Successfully");
                    }
                    else
                    {
                        Console.WriteLine("Error...");
                    }

                    break;
                case 3:
                    Standard stdupdate = new Standard()
                    {
                        StandardId = 1,
                        StandardName = "4th",
                        Description = "fourth"
                    };
                    if (stdbll.updateStandard(stdupdate))
                    {
                        Console.WriteLine("Standard updated Successfully");
                    }
                    else
                    {
                        Console.WriteLine("Error...");
                    }
                    break;
                case 4:
                    Standard s = stdbll.viewStandard(1);

                    if (s != null)
                    {
                        Console.WriteLine($"ID={s.StandardId}\t Name={s.StandardName}\t description={s.Description}");
                    }
                    else
                    {
                        Console.WriteLine("Error...");
                    }
                    break;


                default:
                    break;
            }

            
            Console.ReadLine();
        }
    }
}
