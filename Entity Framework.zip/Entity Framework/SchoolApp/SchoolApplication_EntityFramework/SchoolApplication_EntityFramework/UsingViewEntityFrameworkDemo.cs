﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolApplication_EntityFramework
{
    class UsingViewEntityFrameworkDemo
    {
        static void Main()
        {
            using (DBschoolEntities dbcontext=new DBschoolEntities())
            {
                var studentAddress = dbcontext.StudentViews.ToList();
                foreach (var v in studentAddress)
                {
                    Console.WriteLine($"\t{v.StudentId}\t{v.StudentName}\t{v.StandardId}\t{v.Address1}\t{v.Address2}\t{v.City}\t{v.State}");
                }
                Console.ReadLine();
            }
        }
    }
}
