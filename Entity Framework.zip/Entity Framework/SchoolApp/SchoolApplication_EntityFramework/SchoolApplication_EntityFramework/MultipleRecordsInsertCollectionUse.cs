﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolApplication_EntityFramework
{
    class MultipleRecordsInsertCollectionUse
    {
        static void Main()
        {
            List<Student> stdList = new List<Student>() {
                new Student(){StudentId=121,StudentName="student111",StandardId=12},
                 new Student(){StudentId=122,StudentName="student112",StandardId=12},
                  new Student(){StudentId=123,StudentName="student113",StandardId=12},
            };

            using (DBschoolEntities dbcontext=new DBschoolEntities())
            {
                dbcontext.Students.AddRange(stdList);
                dbcontext.SaveChanges();
            }
            Console.ReadLine();
        }
    }
}
