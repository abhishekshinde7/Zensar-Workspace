﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SchoolApplication_EntityFramework.BLL;

namespace SchoolApplication_EntityFramework
{
    class StoredProcedureEntityFrameWorkDemo
    {
        static void Main()
        {
            StudentBLL sb = new StudentBLL();
            GetStudentById_Result s = sb.getStudentById(102);
            Console.WriteLine($"{s.StandardId}\t{s.StudentId}\t{s.StudentName}");
            Console.ReadLine();
        }
    }
}
