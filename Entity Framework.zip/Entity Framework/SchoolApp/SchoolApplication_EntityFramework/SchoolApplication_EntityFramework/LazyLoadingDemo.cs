﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolApplication_EntityFramework
{
    class LazyLoadingDemo
    {
        static void Main()
        {
            
            using (DBschoolEntities dbcontext = new DBschoolEntities())
            {
                //lazy loading-----------------------------------------------------------------
                //var std =( from s in dbcontext.Standards
                //          join st in dbcontext.Students on s.StandardId equals st.StandardId
                //          select new {s.StandardId,s.StandardName,st.StudentId,st.StudentName }).ToList();

                //Eager loading-----------------------------------------------------------------
                var std = dbcontext.Students.Include("Standard").ToList();
                //  var std = dbcontext.Students.Include("Standard").Where(s=>s.StudentName=="Abhishek").ToList();

                if (std.Count > 0)
                {
                    foreach (var i in std)
                    {
                        Console.WriteLine($"student class:{i.StudentId}\t{i.StudentName}\t{i.StandardId} standard table :\t{i.Standard.StandardName}");

                    }
                }
                    
                Console.ReadLine();

            }

            
        }
    }
}
