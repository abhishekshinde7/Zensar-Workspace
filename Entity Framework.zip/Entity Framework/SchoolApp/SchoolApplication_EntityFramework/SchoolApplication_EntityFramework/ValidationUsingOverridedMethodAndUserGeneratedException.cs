﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.Validation;

namespace SchoolApplication_EntityFramework
{
    class ValidationUsingOverridedMethodAndUserGeneratedException
    {
        static void Main()
        {
            try
            {
                Student std = new Student {StudentName=""};
                using (DBschoolEntities dbcontext=new DBschoolEntities())
                {
                    dbcontext.Students.Add(std);
                    dbcontext.SaveChanges();
                }
            }
            catch (DbEntityValidationException ex)
            {
                foreach(DbEntityValidationResult results in ex.EntityValidationErrors)
                {
                    foreach(DbValidationError error in results.ValidationErrors)
                    {
                        Console.WriteLine($"Property:{error.PropertyName}\t Error:{error.ErrorMessage}");
                    }
                  
                }
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
}
