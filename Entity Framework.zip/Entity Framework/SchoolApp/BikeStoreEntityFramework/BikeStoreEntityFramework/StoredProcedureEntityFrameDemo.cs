﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BikeStoreEntityFramework.BLL;

namespace BikeStoreEntityFramework
{
    class StoredProcedureEntityFrameDemo
    {
        static void Main()
        {
            EmployeeBLL sb = new EmployeeBLL();
            EmployeeSalarys_Result sr = sb.EmployeeSalarys_Result(2);
            Console.WriteLine($"{sr.Basic} \t {sr.EmpCode}\t {sr.NetSalary}");
            Console.ReadLine();
        }
    }
}
