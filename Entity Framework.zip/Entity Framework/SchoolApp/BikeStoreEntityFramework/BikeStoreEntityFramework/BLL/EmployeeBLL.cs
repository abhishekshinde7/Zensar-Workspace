﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeStoreEntityFramework.BLL
{
    class EmployeeBLL
    {
        public EmployeeSalarys_Result EmployeeSalarys_Result(int empcode)
        {
            EmployeeSalarys_Result es = new EmployeeSalarys_Result();
            try
            {
                using (EMPZensarEntities dbcontext=new EMPZensarEntities())
                {
                    var s = dbcontext.EmployeeSalarys(empcode);
                    es = s;
                    return s;
                }
            }
            catch
            {
                return null;
            }
        }
    }
}
