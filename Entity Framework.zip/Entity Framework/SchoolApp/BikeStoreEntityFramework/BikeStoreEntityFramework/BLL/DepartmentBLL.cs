﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeStoreEntityFramework.BLL
{
    class DepartmentBLL
    {
        public bool saveDepartment(DepartmentMaster d)
        {
            try
            {
                using (EMPZensarEntities dbcontext=new EMPZensarEntities())
                {
                    dbcontext.DepartmentMasters.Add(d);
                    dbcontext.SaveChanges();
                }
                    return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteDepartment()
        {
            try
            {
                using (EMPZensarEntities dbcontext=new EMPZensarEntities())
                {
                    //  var s = dbcontext.DepartmentMasters.First<DepartmentMaster>(x=>x.EmpDepartment== "");
                    var s = dbcontext.DepartmentMasters.First<DepartmentMaster>(x => x.EmpDepartment == "HR");
                    dbcontext.DepartmentMasters.Remove(s);
                    dbcontext.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

       public List<DepartmentMaster> veiwDepartment()
        {
            using (EMPZensarEntities dbcontext = new EMPZensarEntities())
            {
                List<DepartmentMaster> Dlist=new List<DepartmentMaster>();
                try
                {
                    var s = dbcontext.DepartmentMasters.ToList();
                    Dlist = s;
                    return Dlist;
                }
                catch (Exception ex)
                {
                    return Dlist;
                }
            }
        }
    }
}
