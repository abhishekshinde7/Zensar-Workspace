﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BikeStoreEntityFramework.BLL;

namespace BikeStoreEntityFramework
{
    class Program
    {
        static void Main(string[] args)
        {
            DepartmentBLL db = new DepartmentBLL();
            //DepartmentMaster dm = new DepartmentMaster()
            //{
            //    EmpDepartment = "IT", EmpDesignation = "developer"
            //};
            //if (db.saveDepartment(dm))
            //{
            //    Console.WriteLine("Depart,ment saved successfully");
            //}
            //else
            //{
            //    Console.WriteLine("Error....");
            //}

            //delete method call

            //if (db.DeleteDepartment())
            //{
            //    Console.WriteLine("Department deleted successfully");
            //}
            //else
            //{
            //    Console.WriteLine("Error....");
            //}

            

        }
    }
}
